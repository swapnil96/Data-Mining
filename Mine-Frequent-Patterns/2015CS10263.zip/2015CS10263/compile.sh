#!/bin/bash

g++ -std=c++14 -O3 -o apriori apriori.cpp
g++ -std=c++14 -O3 -o fptree fptree.cpp