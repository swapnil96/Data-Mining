#!/bin/sh

chmod a+x gSpan-64