#!/bin/sh

git clone https://github.com/swapnil96/Data-Mining

# Networkx module of python3 is needed 
# Installation via pip is possible but may require sudo access, so please look into it
sudo pip3 install networkx

