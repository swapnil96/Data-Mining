#!/bin/sh

python3 find.py $1 $2 $3 $4

./gSpan-64 -f datafile -s 0.25 -o -i

./gSpan-64 -f ga -s 0.5 -o -i

python3 predict.py $2 $3

