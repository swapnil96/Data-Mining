2015CS10263: Swapnil Das
2015CS10264: Tanmay Bansal
2015CS10218: B Sourabh

# Libraries

We have used Kdtree library, copyright details can be found in the file COPYING

link: https://github.com/jtsiomb/kdtree